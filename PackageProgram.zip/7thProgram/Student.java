package pack2;
public class Student
{
	private int roll;
	private String name;
	public void setroll(int r)
	{
		roll=r;
	}
	public int getroll()
	{
		return(roll);
	}
	public void setname(String n)
	{
		name=n;
	}
	public String getname()
	{
		return(name);
	}
}
package pack1;
import pack2.Student;
public class Example{
	public static void main(String []args){
		Student s1=new Student();
		s1.setroll(33);
		s1.setname("jack");
		System.out.println("roll is "+s1.getroll());
		System.out.println("name is "+s1.getname());
	}
}
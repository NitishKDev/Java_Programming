package hello;
public class ExamplePackage{
	public static void main(String []args){
		System.out.println("hello package");
	}
}
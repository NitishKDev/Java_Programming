class StudentInheritance extends Person{
	private int roll;
	public void setroll(int r)
	{
		roll=r;
	}
	public int getroll()
	{
		return(roll);
	}
}
	
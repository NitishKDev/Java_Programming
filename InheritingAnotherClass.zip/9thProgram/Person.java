public class Person{
	private int age;
	private String name;
	public void setage(int r)
	{
		age=r;
	}
	public void setname(String n)
	{
		name=n;
	}
	public int getage()
	{
		return(age);
	}
	public String getname()
	{
		return(name);
	}
}
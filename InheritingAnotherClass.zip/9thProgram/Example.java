public class Example{
	public static void main(String []args)
	{
		StudentInheritance s1=new StudentInheritance();
		s1.setage(24);
		s1.setroll(2);
		s1.setname("jack");
		System.out.println("age="+s1.getage());
		System.out.println("roll="+s1.getroll());
		System.out.println("name="+s1.getname());
	}
}